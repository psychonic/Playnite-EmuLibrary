def on_application_started():
    pass

def on_application_stopped():
    pass

def on_library_updated():
    pass

def on_game_starting(game):
    pass

def on_game_started(game):
    pass

def on_game_stopped(game, elapsed_seconds):
    pass

def on_game_installed(game):
    pass

def on_game_uninstalled(game):
    pass

def on_game_selected(args):
    pass