function global:OnApplicationStarted()
{
}

function global:OnApplicationStopped()
{
}

function global:OnLibraryUpdated()
{
}

function global:OnGameStarting()
{
    param(
        $game
    )
}

function global:OnGameStarted()
{
    param(
        $game
    )
}

function global:OnGameStopped()
{
    param(
        $game,
        $elapsedSeconds
    )
}

function global:OnGameInstalled()
{
    param(
        $game
    )     
}

function global:OnGameUninstalled()
{
    param(
        $game
    )    
}

function global:OnGameSelected()
{
    param(
        $selection
    )    
}